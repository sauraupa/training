package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class UpdateServlet extends HttpServlet 

{
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		{
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			String id = request.getParameter("eid");
			String name = request.getParameter("empname");
			String salary = request.getParameter("empsal");
			try
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
				String url = "jdbc:oracle:thin:@localhost:1521:xe";
				String user = "hr";
				String pass = "hr";
				Connection con = DriverManager.getConnection(url,user,pass);
				String sql = "update employee set ename=?, esal=? where id=?";
				PreparedStatement ps = con.prepareStatement(sql);
				ps.setString(1, name);
				ps.setDouble(2,Double.parseDouble(salary));
				ps.setInt(3, Integer.parseInt(id));
				int n = ps.executeUpdate();
				if(n>=1)
				{	
					out.println("<b style='color:green'>added successfully</b>");
					RequestDispatcher rd = request.getRequestDispatcher("viewEmployees.jsp");
					rd.include(request, response);
				}
				else
				{
					out.println("<b style='color:red'>Something went wrong</b>");
					RequestDispatcher rd = request.getRequestDispatcher("updateEmployee.jsp?id="+id);
					rd.include(request, response);
				}
			}
			catch(Exception e)
			{
				out.println(e);
			}
		
	}

	}
	}

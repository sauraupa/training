package com.cg.ems.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.ems.bean.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.EmpService;
import com.cg.ems.service.EmpServiceImpl;

public class TestEmpClient {
	static EmpService empSer=null;
	static Scanner sc=null;
	public static void main(String[] args) {
		empSer=new EmpServiceImpl();
		sc=new Scanner(System.in);
		int choice=0;
		while(true)
		{
			System.out.println("What Do you want to do?");
			System.out.println("1.Add EMP\t"
					+"2.Display All Emp\t\n"
					+"3.Get Employee Details by Employee ID\t\n"
					+"4.Get Employee Details by Employee Name\t\n"
					+"5.Delete Employee Details using Employee ID\t\n"
					+"6.Update Employee Details using Employee ID\t\n"
					+"7.Exit");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1: enterEmpDetails();
			break;
			case 2: fetchAllEmpDetails();
			break;
			case 3: fetchEmpDetailsById();
			break;
			case 4: fetchEmpDetailsByName();
			break;
			case 5: deleteEmpInfoById();
			break;
			case 6: updateEmpInfoById();
			break;
			default:System.exit(0);		
			}
		}

	}
	public static void updateEmpInfoById() {
		sc=new Scanner(System.in);
		System.out.println("Enter Employee ID: ");
		int id1=sc.nextInt();
		System.out.println("Enter new Employee Name: ");
		String name1=sc.next();
		try {
			if(empSer.validateName(name1))
			{
				System.out.println("Enter the new Employee Salary : ");
				float sal1=sc.nextFloat();
				int s1=(int) sal1;
				if(empSer.validateDigit(s1))
				{
					System.out.println(empSer.updateEmp(id1,name1,sal1)+ " rows deleted");
				}
			}
		} catch (Exception e) {

			e.printStackTrace();
		}

	}
	public static void deleteEmpInfoById() {
		sc=new Scanner(System.in);
		System.out.println("Enter Employee ID: ");
		int id1=sc.nextInt();
		try {
			System.out.println(empSer.deleteEmp(id1)+ " rows deleted");
		} catch (Exception e) {

			e.printStackTrace();
		}
	}
	public static void fetchEmpDetailsByName() {

		Employee e4=new Employee();
		try {
			sc=new Scanner(System.in);
			System.out.println("Enter employee name : ");
			String nm=sc.next();
			e4=empSer.getEmpInfoByName(nm);
			System.out.println("ID\t\t NAME \t\t SALARY");
			System.out.println(e4.getEmpNo()+
					"\t\t"+e4.getEmpName()+"\t\t"+e4.getEmpSal());
		} catch (Exception e) {

			e.printStackTrace();
		}
	}
	public static void fetchEmpDetailsById() {

		Employee e3=new Employee();
		try {
			sc=new Scanner(System.in);
			System.out.println("Enter employee id : ");
			int eid=sc.nextInt();
			e3=empSer.getEmpInfoById(eid);
			System.out.println("ID\t\t NAME \t\t SALARY");
			System.out.println(e3.getEmpNo()+
					"\t\t"+e3.getEmpName()+"\t\t"+e3.getEmpSal());
		} catch (Exception e) {

			e.printStackTrace();
		}
	}
	public static void enterEmpDetails()
	{
		System.out.println("Enter Employee Name : ");
		String empName=sc.next();
		try {
			if(empSer.validateName(empName))
			{
				System.out.println(" Enter Employee Salary : ");
				int empSal=sc.nextInt();
				//String eSl=String.valueOf(empSal);
				if(empSer.validateDigit(empSal))
				{
					Employee ee=new Employee();
					ee.setEmpName(empName);
					ee.setEmpSal(empSal);
					int eid=empSer.addEmp(ee);
					if(eid!=0)
					{
						System.out.println("Employee Added");
					}
					else
					{
						System.out.println("Employee Not Added");
					}
				}
			}
		} catch (Exception e) {

			e.printStackTrace();
		}
	}
	public static void fetchAllEmpDetails()
	{
		ArrayList<Employee> ar1=new ArrayList<Employee>();
		try {
			ar1=empSer.fetchAllEmp();
			System.out.println("ID\t\t NAME \t\t SALARY");
			for(Employee i:ar1)
			{
				System.out.println(i.getEmpNo()+
						"\t\t"+i.getEmpName()+"\t\t"+i.getEmpSal());
			}
		} catch (Exception e) {

			e.printStackTrace();
		}
	}
}

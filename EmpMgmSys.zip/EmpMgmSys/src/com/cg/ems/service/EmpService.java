package com.cg.ems.service;

import java.util.ArrayList;

import com.cg.ems.bean.Employee;
import com.cg.ems.exception.EmployeeException;

public interface EmpService {
	public int addEmp(Employee emp) throws EmployeeException;
	public ArrayList<Employee> fetchAllEmp() throws EmployeeException;
	public Employee getEmpInfoById(int empId) throws EmployeeException;
	public Employee getEmpInfoByName(String empName) throws EmployeeException;
	public int updateEmp(int empId,String empNewName,float empNewSal) throws EmployeeException;
	public int deleteEmp(int empId) throws EmployeeException;
	public int generateEmpId() throws EmployeeException;
	
	public boolean validateName(String Name) throws EmployeeException;
	public boolean validateDigit(int digit) throws EmployeeException;
	
	
}

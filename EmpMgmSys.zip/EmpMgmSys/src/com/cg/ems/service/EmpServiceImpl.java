package com.cg.ems.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.ems.bean.Employee;
import com.cg.ems.dao.EmpDaoImpl;
import com.cg.ems.dao.EmployeeDao;
import com.cg.ems.exception.EmployeeException;

public class EmpServiceImpl implements EmpService{
	
	EmployeeDao empdao=null;
	public EmpServiceImpl() {
		
		empdao=new EmpDaoImpl();
	}

	@Override
	public int addEmp(Employee emp) throws EmployeeException {

		return empdao.addEmp(emp);
	}

	@Override
	public ArrayList<Employee> fetchAllEmp() throws EmployeeException {

		return empdao.fetchAllEmp();
	}

	@Override
	public Employee getEmpInfoById(int empId) throws EmployeeException {

		return empdao.getEmpInfoById(empId);
	}

	@Override
	public Employee getEmpInfoByName(String empName) throws EmployeeException {

		return empdao.getEmpInfoByName(empName);
	}

	@Override
	public int updateEmp(int empId, String empNewName,float empNewSal) throws EmployeeException {

		return empdao.updateEmp(empId, empNewName, empNewSal);
	}

	@Override
	public int deleteEmp(int empId) throws EmployeeException {

		return empdao.deleteEmp(empId);
	}

	@Override
	public int generateEmpId() throws EmployeeException {

		return empdao.generateEmpId();
	}

	@Override
	public boolean validateName(String Name) throws EmployeeException {

		String regex="[A-Z][a-z]+";
		if(Pattern.matches(regex, Name))
		{
			return true;
		}
		else
		{
			throw new EmployeeException("Please enter correct employee name");
		}
	}

	@Override
	public boolean validateDigit(int digit) throws EmployeeException {

		String empdigit="[0-9]+";
		String digitStr=String.valueOf(digit);
		if(Pattern.matches(empdigit, digitStr))
		{
			return true;
		}
		else
		{
			throw new EmployeeException("Please enter correct employee ID");
		}
	}

}

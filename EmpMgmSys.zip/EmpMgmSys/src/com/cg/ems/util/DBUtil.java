package com.cg.ems.util;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;


public class DBUtil {
	static String url    =null;
	static String unm    =null;
	static String pwd    =null;
	public static Connection getCon() throws IOException, SQLException
	{
		Connection con=null;
		Properties props=getProps();
		url=props.getProperty("dbURL");
		unm=props.getProperty("dbUserName");
		pwd=props.getProperty("dbPwd");
		
		if(con==null)
		{
			con=DriverManager.getConnection(url, unm, pwd);
		}
		return con;
	}
	public static Properties getProps() throws IOException
	{
		FileReader fr=new FileReader("DBInfo.properties");
		Properties props=new Properties();
		props.load(fr);
		return props;
	}
}

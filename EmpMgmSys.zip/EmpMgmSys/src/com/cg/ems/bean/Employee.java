package com.cg.ems.bean;

import java.time.LocalDate;

public class Employee {
	private int empNo;
	private String empName;
	private float empSal;
	private LocalDate empDOJ;
	@Override
	public String toString() {
		return "Employee [empNo=" + empNo + ", empName=" + empName
				+ ", empSal=" + empSal + ", empDOJ=" + empDOJ + "]";
	}
	public Employee(int empNo, String empName, float empSal) {
		super();
		this.empNo = empNo;
		this.empName = empName;
		this.empSal = empSal;
	}
	public Employee() {
		super();
	}
	public Employee(int empNo, String empName, float empSal, LocalDate empDOJ) {
		super();
		this.empNo = empNo;
		this.empName = empName;
		this.empSal = empSal;
		this.empDOJ = empDOJ;
	}
	public int getEmpNo() {
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public float getEmpSal() {
		return empSal;
	}
	public void setEmpSal(float empSal) {
		this.empSal = empSal;
	}
	public LocalDate getEmpDOJ() {
		return empDOJ;
	}
	public void setEmpDOJ(LocalDate empDOJ) {
		this.empDOJ = empDOJ;
	}
}

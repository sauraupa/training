package com.cg.ems.JUnit;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.ems.bean.Employee;
import com.cg.ems.dao.EmpDaoImpl;
import com.cg.ems.dao.EmployeeDao;
import com.cg.ems.exception.EmployeeException;

public class EmpDaoImplTest {
	static EmployeeDao empDao=null;
	@BeforeClass
	public static void beforeClass()
	{
		empDao=new EmpDaoImpl();
		System.out.println("This function is executed "
				+ "once before the execution "
				+ "of All Test cases");
	}
	@AfterClass
	public static void afterClass()
	{
		System.out.println("This function is executed "
				+ "once after the execution "
				+ "of All Test cases");
	}
	@Before
	public void setUp()
	{
		System.out.println("This function is executed "
				+ "once before the execution "
				+ "of each Test cases");
	}
	@After
	public void tearDown()
	{
		System.out.println("This function is executed "
				+ "once after the execution "
				+ "of each Test cases");
	}
	@Test
	public void testAddEmp() throws EmployeeException
	{
		Employee ee=new Employee();
		ee.setEmpNo(105);
		ee.setEmpSal(900);
		ee.setEmpName("Aaa");
		Assert.assertNotSame(0, empDao.addEmp(ee));
	}
	@Test
	public void testFetchAll() throws EmployeeException
	{
		
		Assert.assertNotNull(empDao.fetchAllEmp());
	}
}

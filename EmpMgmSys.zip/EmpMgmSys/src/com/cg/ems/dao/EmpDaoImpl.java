package com.cg.ems.dao;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;




import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


//import javax.annotation.Generated;
import com.cg.ems.bean.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DBUtil;

//CLASS TO PROVIDE DETAILS IN THE ABSTRACT METHODS AND PERFORM THE QUERIES


public class EmpDaoImpl implements EmployeeDao{
	
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	Logger empLogger=null;
	public EmpDaoImpl()
	{
		PropertyConfigurator.configure("log4j.properties");
		empLogger=Logger.getLogger(EmpDaoImpl.class);
	}
	
	@Override
	public int addEmp(Employee emp) throws EmployeeException {
		int eid=generateEmpId();
		int dataInserted=0;
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(QueryMapper.INSTEMPQRY);
			pst.setInt(1, eid);
			pst.setString(2, emp.getEmpName());
			pst.setFloat(3,emp.getEmpSal());
			dataInserted=pst.executeUpdate();
			empLogger.info("data inserted : "+eid);
			if(dataInserted==0)
			{
				eid=0;
				empLogger.info("data not inserted: "+eid);
			}
			
		} catch (Exception e) {
		
			empLogger.log(Level.ERROR,e.getMessage());
			throw new EmployeeException(e.getMessage(),e.getCause());
		} 
		finally
		{
			try {
				pst.close();
				con.close();
			} catch (Exception e) {
				
				empLogger.log(Level.ERROR,e.getMessage());
				throw new EmployeeException(e.getMessage(),e.getCause());
			}
		}
		return eid;
	}

	@Override
	public ArrayList<Employee> fetchAllEmp() throws EmployeeException {
		ArrayList<Employee> list=new ArrayList<Employee>();
		Employee e1=null;
		try {
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(QueryMapper.SELECTALLEMPQRY);
			while(rs.next())
			{
				e1=new Employee(rs.getInt("emp_id"),
						rs.getString("emp_name"),rs.getInt("emp_sal"));
				list.add(e1);
			}
			empLogger.info("Retrieved Data" +list);
		} catch (Exception e) {
			
			empLogger.log(Level.ERROR,e.getMessage());
			throw new EmployeeException(e.getMessage(),e.getCause());
		}
		finally
		{
			try {
				st.close();
				con.close();
				rs.close();
			} catch (Exception e) {
				
				empLogger.log(Level.ERROR,e.getMessage());
				throw new EmployeeException(e.getMessage(),e.getCause());
			}
		}
		return list;
	}

	@Override
	public Employee getEmpInfoById(int empId) throws EmployeeException {
		Employee e2=null;
		try {	
			con=DBUtil.getCon();
			pst=con.prepareStatement(QueryMapper.SELECTEMPBYIDQRY);
			pst.setInt(1,empId);
			rs=pst.executeQuery();
			rs.next();
			e2=new Employee(rs.getInt("emp_id"),
					rs.getString("emp_name"),rs.getInt("emp_sal"));
			
			
		} catch (Exception e) {
			
			empLogger.log(Level.ERROR,e.getMessage());
			throw new EmployeeException(e.getMessage(),e.getCause());
		}
		finally
		{
			try {
				pst.close();
				con.close();
				rs.close();
			} catch (Exception e) {
				
				empLogger.log(Level.ERROR,e.getMessage());
				throw new EmployeeException(e.getMessage(),e.getCause());
			}
		}
		
		return e2;
	}

	@Override
	public Employee getEmpInfoByName(String empName) throws EmployeeException {
		Employee e2=null;
		try {	
			con=DBUtil.getCon();
			pst=con.prepareStatement(QueryMapper.SELECTEMPBYENAMEQRY);
			pst.setString(1, empName);
			rs=pst.executeQuery();
			rs.next();
			e2=new Employee(rs.getInt("emp_id"),
					rs.getString("emp_name"),rs.getInt("emp_sal"));
			
			
		} catch (Exception e) {
			
			empLogger.log(Level.ERROR,e.getMessage());
			throw new EmployeeException(e.getMessage(),e.getCause());
		}
		finally
		{
			try {
				pst.close();
				con.close();
				rs.close();
			} catch (Exception e) {
				
				empLogger.log(Level.ERROR,e.getMessage());
				throw new EmployeeException(e.getMessage(),e.getCause());
			}
		}
		
		return e2;
	}


	@Override
	public int updateEmp(int empId, String empNewName, float empNewSal) throws EmployeeException {
		int update=0;
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(QueryMapper.UPDATEEMPQRY);
			pst.setString(1, empNewName);
			pst.setFloat(2, empNewSal);
			pst.setInt(3, empId);
			update=pst.executeUpdate();
		} catch (Exception e) {
			
			empLogger.log(Level.ERROR,e.getMessage());
			throw new EmployeeException(e.getMessage(),e.getCause());
		}
		finally
		{
			try {
				pst.close();
				con.close();
			} catch (Exception e) {
				
				empLogger.log(Level.ERROR,e.getMessage());
				throw new EmployeeException(e.getMessage(),e.getCause());
			}
		}
		return update;
	}

	@Override
	public int deleteEmp(int empId) throws EmployeeException {
		int deleted=0;
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(QueryMapper.DELETEEMPQRY);
			pst.setInt(1, empId);
			deleted=pst.executeUpdate();
			
		} catch (Exception e) {
			
			empLogger.log(Level.ERROR,e.getMessage());
			throw new EmployeeException(e.getMessage(),e.getCause());
		}
		finally
		{
			try {
				pst.close();
				con.close();
			} catch (Exception e) {
				
				empLogger.log(Level.ERROR,e.getMessage());
				throw new EmployeeException(e.getMessage(),e.getCause());
			}
		}
		return deleted;
	}

	@Override
	public int generateEmpId() throws EmployeeException {
		int generatedEmpId=0;
		try {
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(QueryMapper.SEQQRY);
			rs.next();
			generatedEmpId=rs.getInt(1);
		} catch (Exception e) {
			
			empLogger.log(Level.ERROR,e.getMessage());
			throw new EmployeeException(e.getMessage(),e.getCause());
		}
		finally
		{
			try {
				st.close();
				con.close();
				rs.close();
			} catch (Exception e) {
				
				empLogger.log(Level.ERROR,e.getMessage());
				throw new EmployeeException(e.getMessage(),e.getCause());
			}
		}
		return generatedEmpId;
	}
	

}

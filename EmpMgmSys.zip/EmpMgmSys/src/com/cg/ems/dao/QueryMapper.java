package com.cg.ems.dao;

//INTERFACE TO STORE THE SQL QUERY STATEMENTS IN FINAL VARIABLES

public interface QueryMapper {
	public static final String SEQQRY="SELECT vai_emp_seq.NEXTVAL FROM DUAL";
	public static final String INSTEMPQRY="INSERT INTO emp(emp_id,emp_name,emp_sal) VALUES (?,?,?)";
	public static final String SELECTALLEMPQRY="SELECT * FROM emp";
	public static final String SELECTEMPBYIDQRY="SELECT * FROM emp WHERE EMP_ID=?";
	public static final String SELECTEMPBYENAMEQRY="SELECT * FROM emp WHERE EMP_NAME=?";
	public static final String DELETEEMPQRY="DELETE FROM emp WHERE EMP_ID=?";
	public static final String UPDATEEMPQRY="UPDATE emp SET EMP_NAME=?,EMP_SAL=(EMP_SAL+?) WHERE EMP_ID=?";
}

package com.cg.ems.dao;

import java.util.ArrayList;

import com.cg.ems.bean.Employee;
import com.cg.ems.exception.EmployeeException;

//INTERFACE THAT CONTAINS ABSTRACT METHODS FOR DIFFERENT SQL QUERIES
//ACCESS DATABASE EMPLOYEES WITH INFOS


public interface EmployeeDao {
	public int addEmp(Employee emp) throws EmployeeException;
	public ArrayList<Employee> fetchAllEmp() throws EmployeeException;
	public Employee getEmpInfoById(int empId) throws EmployeeException;
	public Employee getEmpInfoByName(String empName) throws EmployeeException;
	public int updateEmp(int empId,String empNewName,float empNewSal) throws EmployeeException;
	public int deleteEmp(int empId) throws EmployeeException;
	public int generateEmpId() throws EmployeeException;
}
